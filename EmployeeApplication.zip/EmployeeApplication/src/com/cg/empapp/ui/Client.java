package com.cg.empapp.ui;

import java.util.Scanner;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.EmployeeServiceImpl;

public class Client {
	static Employee empobj;
	static EmployeeServiceImpl serviceobj=new EmployeeServiceImpl();
	public static void main(String[] args) throws EmployeeException {
		
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("\n 1-Add Employee\n 2-Get All Employee Details\n 3-Get Employee By Id\n 4-Exit");
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
			    System.out.println("\n Enter id");
			    int id=sc.nextInt();
			    System.out.println("\n Enter name");
			    String name=sc.next();
			    serviceobj.isEmpNameValid(name);
			    System.out.println("\n Enter Salary");
			    int sal=sc.nextInt();
			   serviceobj.isEmpSalaryValid(sal);
			    empobj=new Employee(id,name,sal);
			    serviceobj.insertEmployee(empobj);
			    System.out.println("\nEmployee Information stored successfully for "+id);
				break;
			case 2:
				serviceobj.getAllEmployees();
				break;
			case 3:
				System.out.println("\n Enter Employee Id");
				int empId=sc.nextInt();
				serviceobj.getEmployeeById(empId);
				break;
			case 4:
				System.out.println("\n End");
				System.exit(0);
				break;
			
			}
			System.out.println("Do you want to continue(y/d)");
			char choice=sc.next().charAt(0);
			if(choice=='y' || choice=='Y')
				continue;
			else {
				System.out.println("Thank you");
				System.exit(0);
			}
		}
		}
		


}
