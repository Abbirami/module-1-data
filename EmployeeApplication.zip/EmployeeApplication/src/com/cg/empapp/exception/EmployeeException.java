package com.cg.empapp.exception;

public class EmployeeException extends Exception 
{

	public EmployeeException() {
		
	}
	public EmployeeException(String args) {
		System.out.println(args);
	}

	
}
