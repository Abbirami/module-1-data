package com.cg.empapp.test;

import java.util.HashMap;
import java.util.List;

import org.junit.Test;
public class EmployeeDaoImplTest {
	@Test
	public void Test() {
		HashMap hmobj=new HashMap();
		assert(hmobj instanceof HashMap);
	}

	
}
