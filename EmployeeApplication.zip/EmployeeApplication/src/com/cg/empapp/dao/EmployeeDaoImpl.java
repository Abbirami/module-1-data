package com.cg.empapp.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

/**
 * class to perform business logic
 */
public class EmployeeDaoImpl implements EmployeeDao{
	
	/**
    * map to hold the data
    */
	private static HashMap<Integer,Employee> map=new HashMap<Integer,Employee>();
	
    
    
    /**
    * getter for map
    */   
    public static void setMap(HashMap<Integer,Employee> map)
    {
		EmployeeDaoImpl.map=map;
    }  
    
    /**
     * Setter for the map
     */

    public static HashMap<Integer,Employee> getMap()
    {
		return map;
    }  

@Override
public void insertEmployee(Employee emp) {
	// TODO Auto-generated method stub
	map.put(emp.getEmpId(), emp);
}

@Override
public HashMap<Integer, Employee> getAllEmployees() throws EmployeeException {
	// TODO Auto-generated method stub
	// It checks Employee details are in database or not in database
	 if(map.isEmpty()) {
		  throw new EmployeeException("\n No Employee Found");
	  }
	  else {                                        
		  Set values=map.keySet();
		  Iterator itrobj=values.iterator();
		  int key;
		  Employee value;
		  while(itrobj.hasNext()) {
			  key=(Integer) itrobj.next();
			  value=map.get(key);
			  System.out.println(key+" "+value);
		  }
		  
	  } return null;
 }
@Override
public Employee getEmployeeById(int id) throws EmployeeException {
	// TODO Auto-generated method stub
	// It checks Employee details are in database or not in database
	  Employee empobj=map.get(id);
	  if(map.containsKey(id))
	  {
		  System.out.println(empobj);
	  }
	  else {
		  throw new EmployeeException("\n Employee Id not found");
	  }return empobj;

} }