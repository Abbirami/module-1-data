package com.cg.empapp.service;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.empapp.dao.EmployeeDaoImpl;
import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{
	Scanner scanner=new Scanner(System.in);
EmployeeDaoImpl daoobj=new EmployeeDaoImpl();
	@Override
	public void insertEmployee(Employee emp) {
		// TODO Auto-generated method stub
		daoobj.insertEmployee(emp);
		
	}

	@Override
	public HashMap<Integer, Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		daoobj.getAllEmployees();
		return null;
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return daoobj.getEmployeeById(id);
	}
	
	public boolean isEmpSalaryValid(int empSal) {
		// It checks Employee salary validation
		while(true) {
			if(empSal>0)
				return true;
			else {
				System.out.println("\n  Salary should be greater than 0.");
				System.out.println("Enter Salary");
				empSal=scanner.nextInt();
			}
		}
		
	}
	public boolean isEmpNameValid(String empName) {
		// It checks Employee Name validation
		while(true) {
			if(empName.length()>=3 && Character.isUpperCase(empName.charAt(0))) {
				return true;
			}
			else {
				System.out.println("\n Name is invalid");
				System.out.println("\n Enter Employee name again");
				empName=scanner.next();
			}
		}
	}
	
	
}